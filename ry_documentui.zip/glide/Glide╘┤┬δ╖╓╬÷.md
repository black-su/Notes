#   Glide源码分析


最近对项目做内存优化的过程中，通过MAT查看页面的内存占比，发现只要存在gif图的情况下，glide的内存占比出奇的高。如果内存优化工作需要输出数据对比，那内存占比大头是需要重点关注的对象。
当前项目中内存占比大头主要集中在com.bumptech.glide.gifdecoder.StandardGifDecoder和com.bumptech.glide.load.engine.bitmap_recycle.LruArrayPool这两个类，由此萌生了对Glide进行源码分析的想法。

Glide加载gif图时的内存占比情况：
![avatar][glide_mat]

把Glide中的gif加载禁止掉，改用github上比较流行的gif加载的三方库android_gif_drawable，它的内存占比如下：
![avatar][android_gif_drawable_mat]


Glide绑定生命周期
Glide异步
Glide缓存

官网资料：https://muyangmin.github.io/glide-docs-cn/doc/caching.html

缓存键(Cache Keys)

在 Glide v4 里，所有缓存键都包含至少两个元素：
请求加载的 model（File, Url, Url）。如果你使用自定义的 model, 它需要正确地实现 hashCode() 和 equals()
一个可选的 签名(Signature)
另外，步骤1-3(活动资源，内存缓存，资源磁盘缓存)的缓存键还包含一些其他数据，包括：

宽度和高度
可选的变换（Transformation）
额外添加的任何 选项(Options)
请求的数据类型 (Bitmap, GIF, 或其他)


缓存键EngineKey.java
```
  @Override
  public int hashCode() {
    if (hashCode == 0) {
      hashCode = model.hashCode();
      hashCode = 31 * hashCode + signature.hashCode();
      hashCode = 31 * hashCode + width;
      hashCode = 31 * hashCode + height;
      hashCode = 31 * hashCode + transformations.hashCode();
      hashCode = 31 * hashCode + resourceClass.hashCode();
      hashCode = 31 * hashCode + transcodeClass.hashCode();
      hashCode = 31 * hashCode + options.hashCode();
    }
    return hashCode;
  }
```

缓存

默认情况下，Glide 会在开始一个新的图片请求之前检查以下多级的缓存：

活动资源 (Active Resources) - 现在是否有另一个 View 正在展示这张图片？
内存缓存 (Memory cache) - 该图片是否最近被加载过并仍存在于内存中？
资源类型（Resource） - 该图片是否之前曾被解码、转换并写入过磁盘缓存？
数据来源 (Data) - 构建这个图片的资源是否之前曾被写入过文件缓存？

活动资源ActiveResources.java
```
  //使用HashMap作为保存活动资源缓存的数据结构
  @VisibleForTesting final Map<Key, ResourceWeakReference> activeEngineResources = new HashMap<>();
  //活动资源加入HashMap
  synchronized void activate(Key key, EngineResource<?> resource) {
    ResourceWeakReference toPut =
        new ResourceWeakReference(
            key, resource, resourceReferenceQueue, isActiveResourceRetentionAllowed);

    ResourceWeakReference removed = activeEngineResources.put(key, toPut);
    if (removed != null) {
      removed.reset();
    }
  }
  
  //从HashMap中移除活动资源
  synchronized void deactivate(Key key) {
    ResourceWeakReference removed = activeEngineResources.remove(key);
    if (removed != null) {
      removed.reset();
    }
  }
```

内存缓存接口MemoryCache.java，其实现类为LruResourceCache，继承自LruCache，数据结构和put，get操作均来自LruCache，详情可查看LruCache
```
private final Map<T, Entry<Y>> cache = new LinkedHashMap<>(100, 0.75f, true);
```


活动资源ActiveResources的保存有两个地方，一个是请求到新的资源，将要显示到控件中时，另外一个是Glide中资源复用时，从内存缓存中检查到该资源并复用时，将其加入到活动资源缓存中。
活动资源ActiveResources的作用正如官网资料所说：活动资源缓存中保存的都是View正在展示的图片，一旦不在展示中的图片(释放)，就把它从活动资源缓存中移除

Engine.java
```
  private final ActiveResources activeResources;
  private final MemoryCache cache;

  @Override
  public synchronized void onEngineJobComplete(
      EngineJob<?> engineJob, Key key, EngineResource<?> resource) {
    // A null resource indicates that the load failed, usually due to an exception.
    if (resource != null && resource.isMemoryCacheable()) {
      activeResources.activate(key, resource);//请求到新的资源，将其加入到活动缓存中
    }

    jobs.removeIfCurrent(key, engineJob);
  }
  
  @Override
  public void onResourceReleased(Key cacheKey, EngineResource<?> resource) {
    activeResources.deactivate(cacheKey);//资源被释放的时候，从活动资源缓存中移除
    if (resource.isMemoryCacheable()) {
      cache.put(cacheKey, resource);//资源被释放的时候，将该资源加入到内存资源缓存中
    } else {
      resourceRecycler.recycle(resource, /*forceNextFrame=*/ false);
    }
  }
  
  private EngineResource<?> loadFromCache(Key key) {
    EngineResource<?> cached = getEngineResourceFromCache(key);
    if (cached != null) {
      cached.acquire();
      activeResources.activate(key, cached);//如果从内存缓存中拿到资源，将该资源加入到活动缓存中
    }
    return cached;
  }
  
  private EngineResource<?> getEngineResourceFromCache(Key key) {
    Resource<?> cached = cache.remove(key);//检测到内存缓存中存在该资源，则把它提取出来，并把它从缓存中移除

    final EngineResource<?> result;
    if (cached == null) {
      result = null;
    } else if (cached instanceof EngineResource) {
      // Save an object allocation if we've cached an EngineResource (the typical case).
      result = (EngineResource<?>) cached;
    } else {
      result =
          new EngineResource<>(
              cached, /*isMemoryCacheable=*/ true, /*isRecyclable=*/ true, key, /*listener=*/ this);
    }
    return result;
  }
  
  @Nullable
  private EngineResource<?> loadFromMemory(
      EngineKey key, boolean isMemoryCacheable, long startTime) {
    if (!isMemoryCacheable) {
      return null;
    }

    EngineResource<?> active = loadFromActiveResources(key);//优先从活动缓存中寻找该图片资源
    if (active != null) {
      if (VERBOSE_IS_LOGGABLE) {
        logWithTimeAndKey("Loaded resource from active resources", startTime, key);
      }
      return active;
    }

    EngineResource<?> cached = loadFromCache(key);//活动缓存中没有该图片资源，则尝试从内存缓存中查询
    if (cached != null) {
      if (VERBOSE_IS_LOGGABLE) {
        logWithTimeAndKey("Loaded resource from cache", startTime, key);
      }
      return cached;
    }

    return null;
  }
  
  public <R> LoadStatus load(
      GlideContext glideContext,
      Object model,
      Key signature,
      int width,
      int height,
      Class<?> resourceClass,
      Class<R> transcodeClass,
      Priority priority,
      DiskCacheStrategy diskCacheStrategy,
      Map<Class<?>, Transformation<?>> transformations,
      boolean isTransformationRequired,
      boolean isScaleOnlyOrNoTransform,
      Options options,
      boolean isMemoryCacheable,
      boolean useUnlimitedSourceExecutorPool,
      boolean useAnimationPool,
      boolean onlyRetrieveFromCache,
      ResourceCallback cb,
      Executor callbackExecutor) {
    long startTime = VERBOSE_IS_LOGGABLE ? LogTime.getLogTime() : 0;

    //缓存键
    EngineKey key =
        keyFactory.buildKey(
            model,
            signature,
            width,
            height,
            transformations,
            resourceClass,
            transcodeClass,
            options);

    EngineResource<?> memoryResource;
    synchronized (this) {
      memoryResource = loadFromMemory(key, isMemoryCacheable, startTime);//优先从内存缓存中查找资源

      if (memoryResource == null) {//内存缓存查找资源失败，则从磁盘缓存中查找
        return waitForExistingOrStartNewJob(
            glideContext,
            model,
            signature,
            width,
            height,
            resourceClass,
            transcodeClass,
            priority,
            diskCacheStrategy,
            transformations,
            isTransformationRequired,
            isScaleOnlyOrNoTransform,
            options,
            isMemoryCacheable,
            useUnlimitedSourceExecutorPool,
            useAnimationPool,
            onlyRetrieveFromCache,
            cb,
            callbackExecutor,
            key,
            startTime);
      }
    }

    // Avoid calling back while holding the engine lock, doing so makes it easier for callers to
    // deadlock.
    cb.onResourceReady(
        memoryResource, DataSource.MEMORY_CACHE, /* isLoadedFromAlternateCacheKey= */ false);
    return null;
  }
  

  private <R> LoadStatus waitForExistingOrStartNewJob(
      GlideContext glideContext,
      Object model,
      Key signature,
      int width,
      int height,
      Class<?> resourceClass,
      Class<R> transcodeClass,
      Priority priority,
      DiskCacheStrategy diskCacheStrategy,
      Map<Class<?>, Transformation<?>> transformations,
      boolean isTransformationRequired,
      boolean isScaleOnlyOrNoTransform,
      Options options,
      boolean isMemoryCacheable,
      boolean useUnlimitedSourceExecutorPool,
      boolean useAnimationPool,
      boolean onlyRetrieveFromCache,
      ResourceCallback cb,
      Executor callbackExecutor,
      EngineKey key,
      long startTime) {

    EngineJob<?> current = jobs.get(key, onlyRetrieveFromCache);
    if (current != null) {
      current.addCallback(cb, callbackExecutor);
      if (VERBOSE_IS_LOGGABLE) {
        logWithTimeAndKey("Added to existing load", startTime, key);
      }
      return new LoadStatus(cb, current);
    }

    EngineJob<R> engineJob =
        engineJobFactory.build(
            key,
            isMemoryCacheable,
            useUnlimitedSourceExecutorPool,
            useAnimationPool,
            onlyRetrieveFromCache);

    DecodeJob<R> decodeJob =
        decodeJobFactory.build(
            glideContext,
            model,
            key,
            signature,
            width,
            height,
            resourceClass,
            transcodeClass,
            priority,
            diskCacheStrategy,
            transformations,
            isTransformationRequired,
            isScaleOnlyOrNoTransform,
            onlyRetrieveFromCache,
            options,
            engineJob);

    jobs.put(key, engineJob);

    engineJob.addCallback(cb, callbackExecutor);
    engineJob.start(decodeJob);//启动一个线程执行DecodeJob任务

    if (VERBOSE_IS_LOGGABLE) {
      logWithTimeAndKey("Started new load", startTime, key);
    }
    return new LoadStatus(cb, engineJob);
  }
```


参考：
https://blog.csdn.net/u012124438/article/details/73612492

https://www.jianshu.com/p/d8976cee3a82

https://blog.csdn.net/wzy198852/article/details/17266507

https://blog.csdn.net/qq_15893929/article/details/88721573

https://www.cnblogs.com/billshen/p/13306285.html